from django.shortcuts import render

from django.http import HttpResponse

from datetime import date


def GetOrders(request):
    return render(request, 'orders.html', {'data': {
        'current_date': date.today(),
        'orders': [
            {'title': 'Android', 'id': 1},
            {'title': 'Ios', 'id': 2},
            {'title': 'Windows', 'id': 3},
        ]
    }})
def GetOrder(request, id):
    return render(request, 'order.html', {'data' : {
        'current_date': date.today(),
        'id': id,
        'Info': [
            {'title': 'Android', 'descr': 'Cool Android'},
            {'title': 'Ios', 'descr': 'Cool Ios'},
            {'title': 'Windows', 'descr': 'Windows'},
        ]

    }})




