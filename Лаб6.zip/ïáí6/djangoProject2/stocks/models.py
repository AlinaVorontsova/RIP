from django.db import models

# Create your models here.



class Stock(models.Model):
    os_name = models.CharField(max_length=50, verbose_name="Название OС")
    last_version = models.DecimalField(max_digits=8, decimal_places=2, verbose_name="Номер версии")
    os_descript = models.CharField(max_length=100, verbose_name="Описание OС")
    src = models.CharField(max_length=150, verbose_name="URL картинки")