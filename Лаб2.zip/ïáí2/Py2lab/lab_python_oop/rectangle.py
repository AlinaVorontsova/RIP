from lab_python_oop.figueClass import Figure


class Rectangle(Figure):

    def __init__(self, h, w, color="Синий"):
        self.__w = w
        super(Rectangle, self).__init__(h, color, "Прямоугольник")
        self._strSize = "длина  {}, ширина  {}".format(h, w)


    def schet(self):
        return  self.__w * self._h


