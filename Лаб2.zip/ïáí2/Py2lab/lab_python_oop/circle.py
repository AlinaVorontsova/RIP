from lab_python_oop.figueClass import Figure
import math


class Circle(Figure):

    def __init__(self, h: int, color: str):
        super(Circle, self).__init__(h, color, "Круг")
        self._strSize = "радиус  {}".format(h)

    def schet(self):
        return self._h ** 2 * math.pi
