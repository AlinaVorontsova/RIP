from lab_python_oop.rectangle import Rectangle
import math


class Square(Rectangle):

    __name:str = "Прямоугольник"

    def __init__(self, h, color):
        super(Rectangle, self).__init__(h, color, "Квадрат")
        self._strSize = "длина стороны  {}".format(h)

    def schet(self):
        return self._h * self._h
