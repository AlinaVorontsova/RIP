class ColorShape:
    """Цвет фигуры"""

    def __init__(self, _color="синиЙ"):
        self.set_color(_color)

    def get_color(self):
        return self.__color

    def set_color(self, _color):
        self.__color = _color

    color = property(get_color, set_color)
