from abc import ABC, abstractmethod
from lab_python_oop.figurColor import ColorShape



class Figure(ABC):
    def __init__(self, h, color, name):
        self._color = ColorShape(color).color
        self._h = h
        self._name = name
        self._s = self.schet()

    @abstractmethod
    def schet(self):
        pass

    def __repr__(self) -> str:
        return '{}, его параметры: {},  площадь {}, цвет {}'.format(self._name, self._strSize, self._s, self._color)

    def get_name(self):
        return self._name

    def get_s(self):
        return self._s