from lab_python_oop.rectangle import Rectangle
from lab_python_oop.circle import Circle
from lab_python_oop.square import Square


def main():
    r = Rectangle(18, 18, "синий")
    print(r.get_name())
    print("---------------", r.__repr__())

    c = Circle(18, "зеленый")
    print(c.get_name())
    print("---------------", c.__repr__())

    s = Square(18, "красный")
    print(s.get_name())
    print("---------------", s.__repr__())
    return


if __name__ == "__main__":
    main()
