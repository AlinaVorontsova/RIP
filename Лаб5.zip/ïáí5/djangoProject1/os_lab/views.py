from datetime import date

from django.shortcuts import render

# Create your views here.
from os_lab.models import Mos

def OSList(request):
    return render(request, 'oss.html', {'data' : {
        'current_date': date.today(),
        'os': Mos.objects.all()
    }})

def GetOS(request, id):
    return render(request, 'os.html', {'data': {
        'current_date': date.today(),
        'os': Mos.objects.filter(id=id)[0]
    }})
