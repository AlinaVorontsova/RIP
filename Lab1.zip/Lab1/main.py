import math
import sys


def main():
    kof: list = [0, 0, 0]  # ЛИСТ КОЭФФИЦЕНТОВ
    for i in range(3):  # проходим все коэф
        if len(sys.argv) > i + 1:  # если данный коэф введен параметром
            kof[i] = int(sys.argv[i + 1])
        else:
            kof[i] = inp(i)  # иначе вводим нужный коэф
        while kof[0] == 0:  # проверяем, что коэф А не равен нулю
            kof[0] = inp(0)  # иначе просим повторить ввод

    schet(kof)


def inp(_i: int) -> float:  # красивый ввод значения
    nameKof: list = ["A", "B", "C"]
    print("Введите коэффициент " + nameKof[_i])
    return float(input())


def schet(koaf: list):  # подсчет корней
    root: list = [0, 0]
    d: float
    d = (koaf[1] * koaf[1]) - (4 * koaf[0] * koaf[2])  # выч дискр
    if d < 0:  # если  дискр меньше 0
        print("Ответ\nКорней нет")
        return

    d = math.sqrt(d)  # корень из дискр
    root[0] = (-koaf[1] - d) / (2 * koaf[0])
    root[1] = (-koaf[1] + d) / (2 * koaf[0])
    d = 0
    print("Ответ:")
    if (root[0] > 0):
        root[0] = math.sqrt(root[0])
        d += 1
        print("x", d, "= ", root[0], sep='')
        d += 1
        print("x", d, "= ", -root[0], sep='')

    if (root[1] > 0):
        root[1] = math.sqrt(root[1])
        d += 1
        print("x", d, "= ", root[1], sep='')
        d += 1
        print("x", d, "= ", -root[1], sep='')

    if d == 0:
        print("Корней нет")
        return


if __name__ == "__main__":
    main()
