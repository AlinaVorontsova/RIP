from django.contrib import admin

from gallery.models import Museum, Art

class MuseumAdmin(admin.ModelAdmin):
    list_display = ['Name', 'Location', 'History']

class ArtAdmin(admin.ModelAdmin):
    list_display = ['Art_pict', 'name_painter', 'release_year', 'History']

admin.site.register(Museum, MuseumAdmin)
admin.site.register(Art, ArtAdmin)